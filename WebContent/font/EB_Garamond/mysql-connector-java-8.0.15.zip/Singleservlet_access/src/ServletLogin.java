

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



/**
 * Servlet implementation class Servletlogin
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// questo counter è visibile solo in questa servlet
	// e conta il numero di accessi totale da parte di chiunque accede a questa servlet
	// da quando viene deployed sul server
	private int servletCount;  

	   public void  init() throws ServletException {
	      // inizializzazione 
	      servletCount = 0;
	   }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		// Contatori   
		servletCount++;     // aggiornamento livello di scoping -> servlet
		Integer sessionCount;   // livello di scoping -> session
		Integer applicationCount;  // livello di scoping -> application (servletContext)

		
		HttpSession session=request.getSession();      // lettura ed aggiornamento -> session
		sessionCount = (Integer)session.getAttribute("counter");
		if (sessionCount != null) 
    			sessionCount++;
		else 
			sessionCount = 1;	
    		session.setAttribute("counter", sessionCount);
	
    		
        ServletContext application = getServletContext();   // lettura ed aggiornamento -> application
        applicationCount = (Integer)application.getAttribute("counter");
        if (applicationCount != null)
        		applicationCount++;
        	else
        		applicationCount = 1;
        application.setAttribute("counter", applicationCount);
        
        
    	// codice per recuperare login e password
        
		Boolean param = false;
		String usr = "", psw = "";

	
		Cookie[] c = request.getCookies();   // tramite cookie
		if (c!=null) { 
			for(int i=0;i<c.length;i++) {
				if (c[i].getName().equals("usr")) 
					usr = c[i].getValue();
				if (c[i].getName().equals("psw")) 
						psw = c[i].getValue();	
			}
		} 	
		if (usr.equals("") || psw.equals("")){		// se recupero tramite cookie fallisce tramite parametri	
			String temp;                        
		 	temp = request.getParameter("usr");
		 	if (temp!= null) {
		 		usr = temp;
		 		temp = request.getParameter("psw");   
		 		if (temp!= null) {
		 			psw = temp;
		 			param = true;         // recupero tramite parametri di entrambi gli input ha avuto successo
		 		}
		 	}
		}

		// da qui in poi usr e psw sono settati a "" solo se il recupero è fallito   -- INEFFICIENTE -- il problema sarà risolto riorganizzando in MVC
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			// 1. Effettuo connessione al database
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/accesso?verifyServerCertificate=false&useSSL=true", "root", "studentiTSW");
			
			// 2. Crea lo statement
			Statement st = conn.createStatement();
			
			// 3. esegui la query
			ResultSet res = st.executeQuery("SELECT * FROM accesso.registration WHERE login = '" + usr + "' AND password = '" + psw + "'");
			
			// 4. Prendi il risultato
			if(res.next())
			{
				// l'utente è ammesso al sito: inserisci dati in cookies e dai risposta
				Cookie usrcookie = new Cookie("usr", usr);
				Cookie pswcookie = new Cookie("psw", psw);
				response.addCookie(usrcookie);
				response.addCookie(pswcookie);
				
				PrintWriter out = response.getWriter();
				out.println("<html><body>");
				out.println("<h1>Ciao " + res.getString("nome") + "</h1>");
				out.println("<br /><br />");
				out.println("In questa applicazione ci sono stati i seguenti numeri di accessi:<br />");
				out.println("A livello di questa SERVLET (solo ServletLogin) " + servletCount + " <br />");
				out.println("A livello di SESSIONE: " + sessionCount + " <br />");
				out.println("A livello di APPLICAZIONE (sia ServletLogin che ServletLogout): " + applicationCount + " <br />");

				out.println("<a href='ServletLogin'>Accedi di nuovo alla pagina</a>");
				out.println(" o <a href='ServletLogout'>Logout</a>");
				out.println("</body></html>");
			}
			else
			{    // i dati utente non sono stati inviati (usr= psw = "") oppure non sono in db -> presenta il form di login
				PrintWriter out = response.getWriter();

				out.println("<!DOCTYPE html>");
				out.println("<html>");
				out.println("<head>");
					out.println("<title>Login</title>");
				out.println("</head>");
				if (param) {                 // se i dati (sbagliati) sono stai recuperati dai parametri aggiungi anche questo
					out.println("<h1>ACCESS DENIED</h1>");
					out.println("<h3>Please insert the correct Login data</h3>");
				}
				
//				 out.println("<h1>" + param + " " + " "+ usr + " " + psw + "</h1>");
				
				out.println("<h1>Login</h1>");
				out.println("<form method='post' action='ServletLogin'>");
					out.println("<input type='text' name='usr' value='' placeholder='Username1' required /> ");
					out.println("<input type=1'password' name='psw' value='' placeholder='Password' required /> ");
					out.println("<input type='submit' value='Login' />");
				out.println("</form>");

				out.println("</body></html>");
				
			}
			
			conn.close();
		}
		catch(Exception e)
		{
			PrintWriter out = response.getWriter();
			
			out.println("<html><body>");
			out.println("OOPS!! Qualcosa è andato storto <br/><br/>" + e.toString());
			e.printStackTrace();
			out.println("<br /><br />");
			out.println("<a href='index.html'>HOME</a>");
			out.println("</body></html>");
			
		}
		}
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
